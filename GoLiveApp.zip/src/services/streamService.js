import apiClient from "../api/apiClient";

export const getLiveStreams = async ()=> {
    const response = await apiClient.get("/streams?status=LIVE")
    return response.data;
}

export const getStreamById = async (id) => {
    const response = await apiClient.get(`streams/${id}`)
    return response.data;
}

export const createStream = async (data) => {
  const response = await apiClient.post("/streams", data)
  return response.data
}
 
