import { useEffect, useState } from "react"
import { useParams } from "react-router"
import Layout from "../components/Layout"
import { getStreamById } from "../services/streamService"

export default function  StreamSetup() {

  const { streamId } = useParams()

  const [stream, setStream] = useState(null);

  useEffect(() => {

    const fetchStream = async () => {

      const data = await getStreamById(streamId)

      setStream(data)

    }

    fetchStream()

  }, [streamId])

  if (!stream) {
    return <p className="p-6 text-gray-400">Loading stream setup...</p>
  }

  const rtmpUrl = "rtmp://localhost/live"

  const copy = (text) => {
    navigator.clipboard.writeText(text)
  }

  return (
    <Layout>

      <h1 className="text-2xl font-bold mb-6">
        Stream Setup
      </h1>

      <div className="bg-[#18181b] p-6 rounded-lg max-w-2xl space-y-6">

        {/* RTMP URL */}

        <div>

          <p className="text-sm text-gray-400 mb-1">
            Server URL
          </p>

          <div className="flex gap-2">

            <input
              value={rtmpUrl}
              readOnly
              className="flex-1 bg-[#0e0e10] p-2 rounded"
            />

            <button
              onClick={()=>copy(rtmpUrl)}
              className="bg-purple-600 px-3 rounded"
            >
              Copy
            </button>

          </div>

        </div>

        {/* Stream Key */}

        <div>

          <p className="text-sm text-gray-400 mb-1">
            Stream Key
          </p>

          <div className="flex gap-2">

            <input
              value={stream.streamKey}
              readOnly
              className="flex-1 bg-[#0e0e10] p-2 rounded"
            />

            <button
              onClick={()=>copy(stream.streamKey)}
              className="bg-purple-600 px-3 rounded"
            >
              Copy
            </button>

          </div>

        </div>

        {/* Instructions */}

        <div className="border-t border-gray-700 pt-4">

          <h2 className="font-semibold mb-2">
            OBS Setup
          </h2>

          <ol className="text-sm text-gray-400 space-y-1">

            <li>1. Open OBS Studio</li>
            <li>2. Go to Settings → Stream</li>
            <li>3. Choose Custom Streaming Server</li>
            <li>4. Paste the Server URL</li>
            <li>5. Paste the Stream Key</li>
            <li>6. Click Start Streaming</li>

          </ol>

        </div>

      </div>

    </Layout>
  )
}
