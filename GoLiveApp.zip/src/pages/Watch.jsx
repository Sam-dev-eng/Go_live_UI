import { useEffect, useState } from "react"
import { useParams } from "react-router"
import Chat from "../components/Chat"
import Layout from "../components/Layout"
import VideoPlayer from "../components/VideoPlayer"
import { getStreamById } from "../services/streamService"

export default function Watch() {
  const { streamId } = useParams()
  const [stream, setStream] = useState(null)

  useEffect(() => {

    const fetchStream = async () => {

      try {
        const data = await getStreamById(streamId)
        setStream(data)
      } catch (err) {
        console.error("Failed to load stream")

      }

    }

    fetchStream()

  }, [streamId])

  if (!stream) {
    return <p className="text-gray-400 p-6">Loading stream...</p>
  }

  return (
    <Layout>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <div className="lg:col-span-2">

          <VideoPlayer streamKey={stream.streamKey} />

          <div className="mt-4">

            <h1 className="text-xl font-bold">
              {stream.title}
            </h1>

            <p className="text-gray-400 text-sm">
              {stream.viewerCount} watching
            </p>

          </div>

        </div>

        <div className="lg:col-span-1">
            <Chat streamId={streamId} />
        </div>

        <div className="bg-[#18181b] rounded-lg p-4">

          <p className="text-gray-400">
            Chat coming soon
          </p>

        </div>

      </div>

    </Layout>
  )
}