import { useNavigate } from "react-router-dom"

export default function StreamCard({id,thumbnail,title,streamer,viewerCount}) {

  const navigate = useNavigate()

  return (
    <div
      onClick={() => navigate(`/watch/${id}`)}
      className="cursor-pointer"
      
    >

      <div className="relative">

        <img
          src={thumbnail}
          className="rounded-lg w-full h-40 object-cover"
        />

        <div className="absolute top-2 left-2 bg-red-600 text-xs px-2 py-1 rounded">
          LIVE
        </div>

        <div className="absolute bottom-2 left-2 text-xs bg-black/70 px-2 py-1 rounded">
          {viewerCount} viewers
        </div>

      </div>

      <div className="mt-2">

        <p className="text-sm font-semibold line-clamp-1">
          {title}
        </p>

        <p className="text-xs text-gray-400">
          {streamer}
        </p>

      </div>

    </div>
  )
}