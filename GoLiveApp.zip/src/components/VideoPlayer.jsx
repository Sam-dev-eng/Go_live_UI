import { useEffect, useRef, useState } from "react"
import Hls from "hls.js"

export default function VideoPlayer({ streamKey }) {

  const videoRef = useRef(null)

  const [error, setError] = useState(false)

  const retryRef = useRef(null)

  useEffect(() => {

    if (!streamKey) return

    const video = videoRef.current

    const streamUrl =
      `${import.meta.env.VITE_MEDIA_BASE_URL}/live/${streamKey}/master.m3u8`

    let hls

    const loadStream = () => {

      setError(false)

      if (Hls.isSupported()) {

        hls = new Hls({
          enableWorker: true,
          lowLatencyMode: true
        })

        hls.loadSource(streamUrl)
        hls.attachMedia(video)

        hls.on(Hls.Events.ERROR, (event, data) => {

          console.log("HLS error:", data)

          if (data.fatal) {

            setError(true)

            hls.destroy()

            startRetry()

          }

        })

      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {

        video.src = streamUrl

      }

    }

    const startRetry = () => {

      if (retryRef.current) return

      retryRef.current = setInterval(() => {

        console.log("Retrying stream...")

        loadStream()

      }, 10000)

    }

    loadStream()

    return () => {

      if (hls) hls.destroy()

      if (retryRef.current) {
        clearInterval(retryRef.current)
      }

    }

  }, [streamKey])

  return (
    <div className="aspect-video w-full bg-black rounded-lg overflow-hidden relative">

      <video
        ref={videoRef}
        controls
        autoPlay
        className="w-full h-full"
      />

      {error && (

        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 text-gray-300">

          <p className="text-lg font-semibold">
            Stream Offline

            Retring in 10 seconds...
          </p>

          <p className="text-sm">
            Waiting for streamer to go live...
          </p>

        </div>

      )}

    </div>
  )
}